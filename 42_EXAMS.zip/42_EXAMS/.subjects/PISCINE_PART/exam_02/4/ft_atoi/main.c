#include <stdio.h>

int		ft_atoi(char *s);

int		main(int argc, char **argv)
{
	printf("%d",ft_atoi(argv[1]));
	return(0);
}
